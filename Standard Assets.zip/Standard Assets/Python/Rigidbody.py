class ImportComponent:
    def __init__(self,indCompo):
        self.name="Rigidbody"
        self.nameCasio="RigdBody"
        self.mainframe=LabelFrame(AllComponentframe, text="Rigidbody")
        self.mainframe.pack()
        self.varActif=IntVar()
        self.varActif.set(1)
        self.CheckActif = Checkbutton(self.mainframe,variable=self.varActif,text="Actif",state= ACTIVE,offvalue=0,onvalue=1)
        self.CheckActif.grid(row=0,column=0)
        self.Bouton_Remove = Button(self.mainframe, text ='Remove', command=self.Remove)
        self.Bouton_Remove.grid(row=0,column=1)


        self.Entry_Massframe=Frame(self.mainframe)
        self.Entry_Massframe.grid(row=1,column=0)
        self.label_Mass=Label(self.Entry_Massframe, text="Mass :")
        self.label_Mass.grid(row=0,column=0)
        self.var_Entry_Mass=StringVar()
        self.var_Entry_Mass.set("1")
        self.var_Entry_Mass.trace("w", self.updateMass)
        self.entry_Mass=Entry(self.Entry_Massframe,textvariable=self.var_Entry_Mass)
        self.entry_Mass.grid(row=0,column=1)
        self.velocity=0
    def Remove(self):
        for ind,i in enumerate((Pj.Elements[Pj.selected]).listComponent):
            if i[0].mainframe==self.mainframe:
                del (Pj.Elements[Pj.selected]).listComponent[ind]
        self.mainframe.destroy()
    def SaveData(self):
        return [int(self.varActif.get()),int(self.var_Entry_Mass.get()),self.velocity]
    def DataCompile(self):
        a=self.SaveData()
        a.insert(1,self.nameCasio)
        return a
    def LoadData(self,Data):
        varActif,var_Entry_Mass,velocity=Data
        self.varActif.set(str(varActif))
        self.var_Entry_Mass.set(str(var_Entry_Mass))
    def updateMass(self,*args):
        try:
            self.var_Entry_Mass.set(str(int(self.var_Entry_Mass.get())))
        except:
            self.var_Entry_Mass.set("0")
        
