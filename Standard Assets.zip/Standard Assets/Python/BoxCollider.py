class ImportComponent:
    def __init__(self,indCompo):
        self.name="Box Collider"
        self.nameCasio="BoxColi"
        self.mainframe=LabelFrame(AllComponentframe, text="Box Collider")
        self.mainframe.pack()
        self.varActif=IntVar()
        self.varActif.set(1)
        self.CheckActif = Checkbutton(self.mainframe,variable=self.varActif,text="Actif",state= ACTIVE,offvalue=0,onvalue=1)
        self.CheckActif.grid(row=0,column=0)
        self.Bouton_Remove = Button(self.mainframe, text ='Remove', command=self.Remove)
        self.Bouton_Remove.grid(row=0,column=1)


        self.varTrigger=IntVar()
        self.varTrigger.set(0)
        self.CheckTrigger = Checkbutton(self.mainframe,variable=self.varTrigger,text="Trigger",offvalue=0,onvalue=1)
        self.CheckTrigger.grid(row=1,column=0)

        self.coliH=0
        self.coliB=0
        self.coliG=0
        self.coliD=0
    def Remove(self):
        for ind,i in enumerate((Pj.Elements[Pj.selected]).listComponent):
            if i[0].mainframe==self.mainframe:
                del (Pj.Elements[Pj.selected]).listComponent[ind]
        self.mainframe.destroy()
    def SaveData(self):
        return [int(self.varActif.get()),int(self.varTrigger.get()),self.coliH,self.coliB,self.coliG,self.coliD]
    def DataCompile(self):
        a=self.SaveData()
        a.insert(1,self.nameCasio)
        return a
    def LoadData(self,Data):
        varActif,varTrigger,self.coliH,self.coliB,self.coliG,self.coliD=Data
        self.varActif.set(str(varActif))
        self.varTrigger.set(str(varTrigger))
