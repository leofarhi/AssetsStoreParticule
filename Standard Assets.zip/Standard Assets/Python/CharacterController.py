class ImportComponent:
    def __init__(self,indCompo):
        self.name="Character Controller"
        self.nameCasio="CtrlPlat"
        self.mainframe=LabelFrame(AllComponentframe, text="Character Controller")
        self.mainframe.pack()
        self.varActif=IntVar()
        self.varActif.set(1)
        self.CheckActif = Checkbutton(self.mainframe,variable=self.varActif,text="Actif",state= ACTIVE,offvalue=0,onvalue=1)
        self.CheckActif.grid(row=0,column=0)
        self.Bouton_Remove = Button(self.mainframe, text ='Remove', command=self.Remove)
        self.Bouton_Remove.grid(row=0,column=1)


        self.label_IdleRight=Label(self.mainframe, text="Idle Right :")
        self.label_IdleRight.grid(row=1,column=0)
        self.CurSelectIdleRight = StringVar()
        self.LstIdleRight = ttk.Combobox(self.mainframe, textvariable=self.CurSelectIdleRight)
        self.LstIdleRight.grid(row=2,column=0)
        self.LstIdleRight.bind('<<ComboboxSelected>>', self.Choix)

        self.label_IdleLeft=Label(self.mainframe, text="Idle Left :")
        self.label_IdleLeft.grid(row=3,column=0)
        self.CurSelectIdleLeft = StringVar()
        self.LstIdleLeft = ttk.Combobox(self.mainframe, textvariable=self.CurSelectIdleLeft)
        self.LstIdleLeft.grid(row=4,column=0)
        self.LstIdleLeft.bind('<<ComboboxSelected>>', self.Choix)

        self.label_WalkRight=Label(self.mainframe, text="Walk Right :")
        self.label_WalkRight.grid(row=5,column=0)
        self.CurSelectWalkRight = StringVar()
        self.LstWalkRight = ttk.Combobox(self.mainframe, textvariable=self.CurSelectWalkRight)
        self.LstWalkRight.grid(row=6,column=0)
        self.LstWalkRight.bind('<<ComboboxSelected>>', self.Choix)

        self.label_WalkLeft=Label(self.mainframe, text="Walk Left :")
        self.label_WalkLeft.grid(row=7,column=0)
        self.CurSelectWalkLeft = StringVar()
        self.LstWalkLeft = ttk.Combobox(self.mainframe, textvariable=self.CurSelectWalkLeft)
        self.LstWalkLeft.grid(row=8,column=0)
        self.LstWalkLeft.bind('<<ComboboxSelected>>', self.Choix)
        
        self.Bouton_Reload = Button(self.mainframe, text ="Reload Images", command=self.ReloadImg)
        self.Bouton_Reload.grid(row=9,column=0)
        self.ReloadImg()
        self.AddImg=["","","",""]
        self.tickFrame=0
        self.Direction=90
    def Choix(self,event):
        try:
            for ind2,o in enumerate([self.LstIdleRight.get(),self.LstIdleLeft.get(),self.LstWalkRight.get(),self.LstWalkLeft.get()]):
                for ind,i in enumerate(Pj.ImageLoad):
                    if (i[1])[2]==str(o):
                        self.AddImg[ind2]=(Pj.ImageLoad[ind])[1]
        except:
            ""
        #print(self.AddImg)
    def ReloadImg(self):
        _temp=[]
        for ind,i in enumerate(Pj.ImageLoad):
            _temp.append((i[1])[2])
        self.LstIdleRight['values'] = tuple(_temp)
        self.LstIdleLeft['values'] = tuple(_temp)
        self.LstWalkRight['values'] = tuple(_temp)
        self.LstWalkLeft['values'] = tuple(_temp)
    def Remove(self):
        for ind,i in enumerate((Pj.Elements[Pj.selected]).listComponent):
            if i[0].mainframe==self.mainframe:
                del (Pj.Elements[Pj.selected]).listComponent[ind]
        self.mainframe.destroy()
    def SaveData(self):
        temp=["","","",""]
        self.Choix("")
        for ind,i in enumerate(self.AddImg):
            try:
                temp[ind]=i[2]
            except:
                ""
        a=[self.varActif.get()]+temp+[self.tickFrame,self.Direction]
        return a
    def FoundPicture(self,RepImg):
        for ind,i in enumerate(ImgBmp):
            if i[2]==RepImg:
                ind=ind+1
                return ind
        return 1
    def DataCompile(self):
        a=self.SaveData()
        a.insert(1,self.nameCasio)
        a[2]=self.FoundPicture(a[2])
        a[3]=self.FoundPicture(a[3])
        a[4]=self.FoundPicture(a[4])
        a[5]=self.FoundPicture(a[5])
        return a
    def LoadData(self,Data):
        varActif,IR,IL,RR,RL,tickFrame,Direction=Data
        self.varActif.set(varActif)
        self.ReloadImg()
        try:
            b=[IR,IL,RR,RL]
            for ind2,o in enumerate([self.LstIdleRight,self.LstIdleLeft,self.LstWalkRight,self.LstWalkLeft]):
                for ind,i in enumerate(Pj.ImageLoad):
                    if b[ind2]==(i[1])[2]:
                        o.current(ind)
        except:
            ""
        self.Choix("")
